public class TesteListaLigada {
  public static void main(String[] args) {
   ListaLigada lista = new ListaLigada();
    
    Pessoa a = new Pessoa();
    a.nome = "Maria";
    a.idade = 30;

    lista.inserir(a);
    lista.imprimir();

  }
}