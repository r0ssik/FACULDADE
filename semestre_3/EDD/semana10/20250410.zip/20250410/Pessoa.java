public class Pessoa {
  String nome;
  int idade;
}