public class Noh {
  Pessoa info;
  Noh proximo;
}